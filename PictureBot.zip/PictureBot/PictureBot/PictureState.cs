﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PictureBot
{
    public class PictureState
    {
        public string Greeted { get; set; } = "not greeted";
        // A list of things that users have said to the bot
        public List<string> UtteranceList { get; private set; } = new List<string>();
        public string Search { get; set; } = "";
        public string Searching { get; set; } = "no";
    }
}
